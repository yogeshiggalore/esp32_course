/* while loop example */
#include <stdio.h>
int main()
{
    int number = 1;
    while (number <= 10)
    {
        printf("%d \n", number);
        number++;
    }

    printf("code ends here\n");
    return 0;
}