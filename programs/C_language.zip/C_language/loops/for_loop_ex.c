/* for loop example */
#include <stdio.h>
int main()
{
    int number = 0;
    for (number = 1; number <= 10; number++)
    {
        printf("%d \n", number);
    }

    printf("code ends here\n");
    return 0;
}