/* include standard headers */
#include <stdio.h>  

int main()  
{  
    int age = 15;

    if(age>=18)  
    {  
        printf("You are eligible to vote\n");   
    }  
    else   
    {  
        printf("Sorry ... you are not eligible to vote\n");   
    }  

    printf( "code ends here\n" );

    return 0;
}  