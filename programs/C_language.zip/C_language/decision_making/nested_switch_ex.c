/* nested switch example */

#include <stdio.h>

int main()
{
    int i = 10;
    int j = 20;

    switch (i)
    {
        case 10:
            printf("the value of i evaluated in outer switch: %d\n", i);
        case 20:
            switch (j)
            {
                case 20:
                printf("The value of j evaluated in nested switch: %d\n", j);
            }
    }

    printf("Exact value of i is : %d\n", i);
    printf("Exact value of j is : %d\n", j);

    printf("code ends here \n");
    return 0;
}